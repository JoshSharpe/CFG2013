from MHDC.models import *
from django.contrib import admin

admin.site.register(UserProfile)
admin.site.register(SelfHelpApplication)
admin.site.register(DocCheckList)
admin.site.register(SelfHelpStaffChecklist)
admin.site.register(HomeRepair)
admin.site.register(LivingInHome)
admin.site.register(Month1)
admin.site.register(Month2)
admin.site.register(Month3)
admin.site.register(Month4)
admin.site.register(Month5)
admin.site.register(RepairChecklist)
admin.site.register(RepairInternalChecklist)
